class Categories:
    def __init__(self):
        self._categories = ['expense', ['food', ['meal', 'snack', 'drink'], 'transportation', ['bus', 'railway']], 'income', ['salary', 'bonus']]

    @property
    def indented_list(self):
        def indented_list_gen(categories, level=0):
            if type(categories) == list:
                for child in categories:
                    yield from indented_list_gen(child, level + 1)
            else:
                yield f'{" " * 2 * (level - 1)}- {categories}'
        return list(indented_list_gen(self._categories))

    def view(self, categories=None, level=0):
        """List all the provided categories hierarchically."""
        if not categories:
            categories = self._categories

        if type(categories) == list:
            for child in categories:
                self.view(child, level + 1)
        else:
            print(f'{" " * 2 * (level - 1)}- {categories}')

    def is_category_valid(self, category, categories=None):
        """List all the provided categories hierarchically."""
        if not categories:
            categories = self._categories

        if type(categories) == list:
            for child in categories:
                if self.is_category_valid(category, child):
                    return True
            return False
        else:
            return category == categories

    def find_subcategories(self, category):
        """Find all records in the specified category or in a subcategory under that one."""
        def find_subcategories_gen(category, categories, found=False):
            if type(categories) == list:
                for index, child in enumerate(categories):
                    yield from find_subcategories_gen(category, child, found)
                    if child == category and index + 1 < len(categories) and type(categories[index + 1]) == list:
                        yield from find_subcategories_gen(category, categories[index + 1], True)
            else:
                if categories == category or found:
                    yield categories
        return list(find_subcategories_gen(category, self._categories))
