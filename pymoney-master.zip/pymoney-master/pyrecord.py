import sys
from datetime import date


class Record:
    def __init__(self, id, date, category, description, amount):
        self._id = id
        self._date = date
        self._category = category
        self._description = description
        self._amount = amount

    @property
    def id(self):
        return self._id

    @property
    def date(self):
        return self._date

    @property
    def category(self):
        return self._category

    @property
    def description(self):
        return self._description

    @property
    def amount(self):
        return self._amount


class Records:
    def __init__(self):
        """Read records from records.txt or prompt for initial amount of money."""
        try:
            # Read records from 'records.txt' and load into a list of tuples `records`
            file = open('records.txt', 'r')

            try:
                initial_money, current_record_id = file.readline().split()
                initial_money = int(initial_money)
                current_record_id = int(current_record_id)

                records = []
                for line in file.readlines():
                    record_id, date, category, desc, amt = line.split()
                    records.append(Record(int(record_id), date, category, desc, int(amt)))

                file.close()
                # print('Welcome back!')
            except ValueError:
                sys.stderr.write('Invalid format in records.txt. Deleting the contents.\n')
                file.close()
                raise FileNotFoundError
        except FileNotFoundError:
            # Ask for the initial amount of money
            # initial_money = input('How much money do you have? ')
            # try:
            #     initial_money = int(initial_money)
            # except ValueError:
            #     sys.stderr.write('Invalid value for money. Set to 0 by default.\n')
            #     initial_money = 0
            initial_money = 0
            records = []
            current_record_id = 0

        self._initial_money = initial_money
        self._current_record_id = current_record_id
        self._records = records

    @property
    def initial_money(self):
        return self._initial_money

    def set_initial_money(self, initial_money):
        self._initial_money = initial_money

    def records(self, target_categories=None):
        if target_categories:
            return list(filter(lambda record: record.category in target_categories, self._records))
        else:
            return self._records

    @property
    def balance(self):
        return self._initial_money + sum(map(lambda record: record.amount, self._records))

    def add(self, record, categories):
        """Add a record."""
        if type(record) == str:
            try:
                record_split = record.split()
                if len(record_split) == 3:
                    category, description, amount = record_split
                    record_date = date.today()
                elif len(record_split) == 4:
                    record_date, category, description, amount = record_split
                    try:
                        record_date = date.fromisoformat(record_date)
                    except ValueError:
                        sys.stderr.write('The format of date should be YYYY-MM-DD.\nFail to add a record.\n')
                        return False
                else:
                    raise ValueError
                record_date = str(record_date)
                assert categories.is_category_valid(category)
                self._current_record_id += 1
                try:
                    record = Record(self._current_record_id, record_date, category, description, int(amount))
                except ValueError:
                    sys.stderr.write('Invalid value for money.\nFail to add a record.\n')
                    self._current_record_id -= 1
                    return False
            except ValueError:
                sys.stderr.write('The format of a record should be like this: food breakfast -50\nFail to add a record.\n')
                return False
            except AssertionError:
                sys.stderr.write('The specified category is not in the category list.\nYou can check the category list by command "view categories".\nFail to add a record.\n')
                return False

        self._records.append(record)
        return True

    def view(self):
        """View the records and the balance."""
        if not self._records:
            print('No records yet.')
        else:
            print('Here\'s your expense and income records:')
            print(f'{"Id":<6} {"Date":<10} {"Category":<15} {"Description":<20} {"Amount":<6}')
            print(f'{"="*6} {"="*10} {"="*15} {"="*20} {"="*6}')
            print('\n'.join(f'{record.id:<6} {record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}' for record in self._records))
            print(f'{"="*(6+10+15+20+6+4)}')

        print(f'Now you have {self.balance} dollars.')

    def delete(self, delete_index):
        """Delete a record."""
        del self._records[delete_index]

    def find(self, target_categories):
        """Find all records whose category is in the target_categories list."""
        if not target_categories:
            print(f'Specified category is not in the category list.')
            return

        filtered_records = list(filter(lambda record: record.category in target_categories, self._records))
        if not filtered_records:
            print(f'No records are under category "{target_categories[0]}".')
            return

        print(f'Here\'s your expense and income records under category "{target_categories[0]}":')
        print(f'{"Id":<6} {"Date":<10} {"Category":<15} {"Description":<20} {"Amount":<6}')
        print(f'{"="*6} {"="*10} {"="*15} {"="*20} {"="*6}')
        print('\n'.join(f'{record.id:<6} {record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}' for record in filtered_records))
        print(f'{"="*(6+10+15+20+6+4)}')

        print(f'The total amount above is {sum(map(lambda record: record.amount, filtered_records))}.')

    def save(self):
        """Write records to file"""
        with open('records.txt', 'w') as file:
            file.write(f'{self._initial_money} {self._current_record_id}\n')
            file.writelines(map(lambda record: f'{record.id} {record.date} {record.category} {record.description} {record.amount}\n', self._records))
