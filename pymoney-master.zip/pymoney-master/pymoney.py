import sys
import tkinter
from datetime import date
from tkinter import ttk, messagebox, font

from pyrecord import Record, Records
from pycategory import Categories

categories = Categories()
records = Records()


def update_initial_money():
    records.set_initial_money(intvar_initial_money.get())
    stringvar_balance.set(f'Now you have {records.balance} dollars.')


def add_record():
    try:
        date.fromisoformat(stringvar_date.get())
        record = Record(0, stringvar_date.get(),
                        combobox_category.get().strip(' -'),
                        entry_description.get(),
                        int(entry_amount.get()))
        records.add(record, categories)
        stringvar_date.set(date.today())
        combobox_category.set('')
        stringvar_description.set('')
        stringvar_amount.set('')
        listbox_records.insert(tkinter.END, f'{record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}')
        stringvar_balance.set(f'Now you have {records.balance} dollars.')
    except ValueError:
        messagebox.showerror(message='The format of date should be YYYY-MM-DD.\nFail to add a record.')


def delete_record():
    delete_index = listbox_records.curselection()[0]
    records.delete(delete_index)
    listbox_records.delete(delete_index)
    stringvar_balance.set(f'Now you have {records.balance} dollars.')


def find_records():
    target_categories = categories.find_subcategories(entry_find.get())
    filtered_records = records.records(target_categories)
    stringvar_records.set(list(map(
        lambda record: f'{record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}',
        filtered_records)))
    stringvar_balance.set(f'Total amount above is {sum(map(lambda record: record.amount, filtered_records))} dollars.')


def reset_find():
    entry_find.delete(0, tkinter.END)
    stringvar_records.set(list(map(
        lambda record: f'{record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}',
        records.records())))
    stringvar_balance.set(f'Now you have {records.balance} dollars.')


root = tkinter.Tk()
root.title('PyMoney')

frame_records = tkinter.Frame(root)
frame_records.pack_propagate(0)
frame_records.pack(side=tkinter.LEFT)

label_find = tkinter.Label(frame_records, text='Find category ', justify=tkinter.LEFT)
label_find.grid(row=1, column=0)
entry_find = tkinter.Entry(frame_records, width=30)
entry_find.grid(row=1, column=1)
button_find = tkinter.Button(frame_records, text='Find', command=find_records)
button_find.grid(row=1, column=2)
button_reset = tkinter.Button(frame_records, text='Reset', command=reset_find)
button_reset.grid(row=1, column=3)

stringvar_records = tkinter.StringVar(
    value=list(map(
        lambda record: f'{record.date:<10} {record.category:<15} {record.description:<20} {record.amount:<6}',
        records.records())))
font_records = font.Font(family='Consolas', size=10)
listbox_records = tkinter.Listbox(frame_records, width=54, listvariable=stringvar_records, font=font_records)
listbox_records.grid(row=2, column=0, columnspan=4)

stringvar_balance = tkinter.StringVar()
stringvar_balance.set(f'Now you have {records.balance} dollars.')
label_balance = tkinter.Label(frame_records, textvariable=stringvar_balance, justify=tkinter.LEFT)  # 'The total amount above is xxx dollars.'
label_balance.grid(row=3, column=0, columnspan=2, sticky='W')
button_delete = tkinter.Button(frame_records, text='Delete', command=delete_record)
button_delete.grid(row=3, column=3)

frame_add = tkinter.Frame(root)
frame_add.pack_propagate(0)
frame_add.pack(side=tkinter.RIGHT)

label_initial = tkinter.Label(frame_add, text='Initial money', justify=tkinter.LEFT)
label_initial.grid(row=0, column=0)
intvar_initial_money = tkinter.IntVar()
intvar_initial_money.set(records.initial_money)
entry_initial = tkinter.Entry(frame_add, width=25, textvariable=intvar_initial_money)
entry_initial.grid(row=0, column=1)

button_update = tkinter.Button(frame_add, text='Update', command=update_initial_money)
button_update.grid(row=1, column=1, sticky='E')

label_empty = tkinter.Label(frame_add, text=' ')
label_empty.grid(row=2, column=0)

label_date = tkinter.Label(frame_add, text='Date', justify=tkinter.LEFT)
label_date.grid(row=3, column=0)
stringvar_date = tkinter.StringVar()
stringvar_date.set(date.today())
entry_date = tkinter.Entry(frame_add, width=25, textvariable=stringvar_date)
entry_date.grid(row=3, column=1)

label_category = tkinter.Label(frame_add, text='Category', justify=tkinter.LEFT)
label_category.grid(row=4, column=0)
combobox_category = ttk.Combobox(frame_add, value=categories.indented_list, width=22, )
combobox_category.grid(row=4, column=1)
combobox_category.set('')

label_description = tkinter.Label(frame_add, text='Description', justify=tkinter.LEFT)
label_description.grid(row=5, column=0)
stringvar_description = tkinter.StringVar()
entry_description = tkinter.Entry(frame_add, width=25, textvariable=stringvar_description)
entry_description.grid(row=5, column=1)

label_amount = tkinter.Label(frame_add, text='Amount', justify=tkinter.LEFT)
label_amount.grid(row=6, column=0)
stringvar_amount = tkinter.StringVar()
entry_amount = tkinter.Entry(frame_add, width=25, textvariable=stringvar_amount)
entry_amount.grid(row=6, column=1)

button_add = tkinter.Button(frame_add, text='Add a record', command=add_record)
button_add.grid(row=7, column=1, sticky='E')

tkinter.mainloop()
records.save()
